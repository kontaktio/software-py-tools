package main

import (
	"./esp32"

	"encoding/csv"
	"encoding/hex"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"regexp"
	"sort"
	"strings"

	"github.com/gookit/color"
)

const CONFIG_FOLDER = "cfg"
const REPORT_FILE = "./Orders/report.csv"
var nrfExtraParams = []string{"-f", "nrf52"}

type DeviceData struct {
	id       string
	uniqueID string
}

func isInSlice(data []string, str string) bool {
	for _, s := range data {
		if s == str {
			return true
		}
	}
	return false
}

func platformNordic() {
	orders, err := getOrders()
	if err != nil {
		color.Error.Print(err)
		return
	}

	if len(orders) == 0 {
		color.Error.Println("No orders found")
		return
	}

	color.Success.Println("Found items: ", orders)

	manufacturedList, _ := getProgrammedDevices()
	reset := promptToReset(manufacturedList)
	if reset {
		color.White.Print("Clearing manufacturing history ... ")
		createEmptyReport()
	}

	for _, orderFolder := range(orders) {
		processOrder(orderFolder)
	}
}

func processOrder(orderFolder string) {
	color.Info.Println()
	color.Info.Printf("Order item found: %s\n", orderFolder)
	toManufactureList, _ := getUniqueIds(orderFolder)
	sort.Slice(toManufactureList, func(i, j int) bool { return toManufactureList[i].id < toManufactureList[j].id })
	color.Info.Printf("Found %d Unique IDs to program\n", len(toManufactureList))
	manufacturedList, _ := getProgrammedDevices()

	// Filter out already manufactured
	filteredSlice := make([]DeviceData, 0)
	for _, s := range toManufactureList {
		if !isInSlice(manufacturedList, s.uniqueID) {
			filteredSlice = append(filteredSlice, s)
		}
	}
	toManufactureList = filteredSlice

	manufacture(toManufactureList, orderFolder)
	//Start manufacturing
	//  Program next device
	//  If ok then go to next device
	//  if error then ask whether go to next device or program once again
	//
}

func main() {
	//select platform
	option := esp32.VerifyEsp32files()
	switch option {
	case false:
		platformNordic()
	case true:
		fmt.Println("Executing programming tools for ESP32 platform")
		esp32.PlatformEsp32()
	}
}

func manufacture(toManufactureList []DeviceData, orderFolder string) {
	firmwareFile, err := findFirmware(orderFolder)
	if err != nil {
		color.Error.Println(err)
		return
	}
	for k := range toManufactureList {
		var input string
		for {
			color.Info.Printf("\n\nPress ENTER to program device with Unique ID [%s]", toManufactureList[k].uniqueID)
			fmt.Scanln(&input)
			if !manufactureNextDevice(toManufactureList[k].id, toManufactureList[k].uniqueID, orderFolder, firmwareFile) {
				color.Yellow.Println("Device has not been programmed correctly. Please try again with new device.")
			} else {
				break
			}

		}
	}
}

func manufactureNextDevice(id string, uniqueID string, orderFolder string, firmwareFile string) bool {
	configFile := fmt.Sprintf("./Orders/%s/%s/%s_%s.hex", orderFolder, CONFIG_FOLDER, id, uniqueID)
	if !fileExists(configFile) {
		color.Error.Printf("Missing config file %s\n", configFile)
		return false
	}
	if !fileExists(firmwareFile) {
		color.Error.Printf("Missing firmware file %s\n", firmwareFile)
		return false
	}

	color.White.Printf("Programming [%s] ----------------------------------------\n", uniqueID)
	color.White.Println("Firmware and config files are OK")
	if !recoverDevice() ||
		!programFirmware(firmwareFile) ||
		!programConfig(configFile) {
		return false
	}
	mac, err := readMacAddress()
	if err != nil {
		return false
	}
	if !appendResultFile(REPORT_FILE, uniqueID, mac) {
		return false
	}
	if !resetDevice() {
		color.Yellow.Println("Device could not be restarted. Please restart device manually and check if configuration has been programmed correctly.")
	} else {
		color.Green.Println("Device programmed correctly.")
	}

	return true
}

func getOrders() (orders []string, err error) {
	files, err := ioutil.ReadDir("./Orders/")
	matched := false
	orders = make([]string, 0)

	if err != nil {
		return orders, err
	}

	for _, f := range files {
		if !f.IsDir() {
			continue
		}
		matched, _ = regexp.MatchString(`^order_config_[0-9A-Za-z\-_.]+$`, f.Name())
		if matched {
			orders = append(orders, f.Name())
		}
	}

	return orders, nil
}

func getUniqueIds(folder string) ([]DeviceData, error) {
	files, err := ioutil.ReadDir("./Orders/" + folder + "/" + CONFIG_FOLDER)
	list := make([]DeviceData, 0)
	pattern := regexp.MustCompile(`(?P<id>[0-9A-Za-z]+)_(?P<unique_id>[0-9A-Za-z]+)\.hex`)

	if err != nil {
		return nil, err
	}

	for _, f := range files {
		result := pattern.FindAllStringSubmatch(f.Name(), -1)
		dev := DeviceData{id: result[0][1], uniqueID: result[0][2]}
		list = append(list, dev)
	}
	return list, nil
}

func findFirmware(folder string) (string, error) {
	files, err := ioutil.ReadDir("./Orders/" + folder)
	if err != nil {
		return "", err
	}

	for _, f := range files {
		matched, _ := regexp.MatchString(`^.+\.hex$`, f.Name())
		sizeMatched := f.Size() > 32 * 1024
		if matched {
			if !sizeMatched {
				return "", errors.New("Firmware file " + f.Name() + " is too small")
			}
			color.White.Print("Using firmware file ")
			color.Warn.Println(f.Name())
			return "./Orders/" + folder + "/" + f.Name(), nil
		}

	}
	return "", errors.New("No firmware .hex file found")
}

func getProgrammedDevices() ([]string, error) {
	path := REPORT_FILE
	var list []string
	if fileExists(path) {
		file, err := os.Open(path)

		if err != nil {
			log.Fatal(err)
		}
		defer file.Close()
		reader := csv.NewReader(file)
		entries, err := reader.ReadAll()
		if err != nil {
			return nil, errors.New("Error parsing CSV file")
		}

		for i, entry := range entries {
			if i == 0 {
				// Skip header
				continue
			}
			list = append(list, entry[0])
		}

		return list, nil
	} else {
		// Create a new report file with headers
		color.White.Print("Report file does not exist, creating ... ")
		createEmptyReport()
		return list, nil
	}
}

func promptToReset(list []string) bool {

	var input string
	if len(list) == 0 {
		return false
	}
	color.Warn.Printf("Found %d already manufactured Unique IDs\n", len(list))
	color.Info.Printf("Press 'R' followed by ENTER to clear list and restart programing or just ENTER to continue previous programming session:")
	fmt.Scanln(&input)
	return strings.ToUpper(input) == "R"
}

func recoverDevice() bool {
	cmd := exec.Command("nrfjprog", append(nrfExtraParams, "--recover")...)
	cmd.Stderr = os.Stderr
	color.White.Printf("Recovering device ... ")
	err := cmd.Run()
	if err != nil {
		color.Red.Printf("Command finished with error: %v\n", err)
		return false
	}
	color.Green.Println("OK")
	return true
}

func programFirmware(firmwarePath string) bool {
	cmd := exec.Command("nrfjprog", append(nrfExtraParams, "--program", firmwarePath)...)
	cmd.Stderr = os.Stderr
	color.White.Printf("Programming device ... ")
	err := cmd.Run()
	if err != nil {
		color.Red.Printf("Command finished with error: %v\n", err)
		return false
	}
	color.Green.Println("OK")
	return true
}

func programConfig(configPath string) bool {
	cmd := exec.Command("nrfjprog", append(nrfExtraParams, "--program", configPath, "--sectorerase")...)
	cmd.Stderr = os.Stderr
	color.White.Printf("Programming config ... ")
	err := cmd.Run()
	if err != nil {
		color.Red.Printf("Command finished with error: %v\n", err)
		return false
	}
	color.Green.Println("OK")
	return true

}

func readMacAddress() (string, error) {
	pattern := regexp.MustCompile(`([0-9A-Za-z]{2} ){5}[0-9A-Za-z]{2}`)
	cmd := exec.Command("nrfjprog", append(nrfExtraParams, "--memrd", "0x100000A4", "--w", "8", "--n", "6")...)
	cmd.Stderr = os.Stderr
	color.White.Printf("Reading MAC ... ")
	out, err := cmd.Output()
	if err != nil {
		color.Red.Printf("Command finished with error: %v\n", err)
		return "", err
	}
	macBytes := pattern.Find(out)
	if macBytes == nil {
		return "", errors.New("Mac address not found")
	}
	color.Green.Println("OK")
	macStrings := strings.Split(string(macBytes), " ")

	firstMacByte := macStrings[5]
	originalMemoryByte, err1 := hex.DecodeString(firstMacByte)
	if err1 != nil {
		panic(err1)
	}

	correctByte := originalMemoryByte[0] | 0xC0
	return fmt.Sprintf("%X:%s:%s:%s:%s:%s", correctByte, macStrings[4], macStrings[3], macStrings[2], macStrings[1], macStrings[0]), nil

}

func appendResultFile(configFile string, uniqueID string, mac string) bool {
	f, err := os.OpenFile(configFile, os.O_APPEND|os.O_WRONLY, 0666)
	color.White.Printf("Writing result ... ")
	if err != nil {
		color.Red.Printf("Command finished with error: %v\n", err)
		return false
	}
	defer f.Close()
	writer := csv.NewWriter(f)
	writer.Write([]string{uniqueID, mac})
	writer.Flush()
	err = writer.Error()
	if err != nil {
		color.Red.Println(err)
		return false
	}
	color.Green.Println("OK")
	return true
}

func resetDevice() bool {
	cmd := exec.Command("nrfjprog", append(nrfExtraParams, "--reset")...)
	cmd.Stderr = os.Stderr
	color.White.Printf("Resetting device ... ")
	err := cmd.Run()
	if err != nil {
		color.Red.Printf("Command finished with error: %v\n", err)
		return false
	}
	color.Green.Println("OK")
	return true
}

func fileExists(filename string) bool {
	info, err := os.Stat(filename)
	if os.IsNotExist(err) {
		return false
	}
	return !info.IsDir()
}

func createEmptyReport() {
	file, err := os.Create(REPORT_FILE)
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()
	writer := csv.NewWriter(file)
	writer.Write([]string{"Unique ID", "MAC"})
	writer.Flush()
	err = writer.Error()
	if err != nil {
		log.Fatal(err)
	}
	color.Green.Println("OK")
}
