# `Orders` folder
The .zip files generated in OFM need to be unpacked into the `Orders` folder. They contain folder with configuration for each beacon that should be programmed on a given programming station.

TODO: Improve this README