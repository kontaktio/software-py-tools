# kdmlight
Standalone version of programming tool

## Preparation:
1) Install `go` following steps from https://golang.org/doc/install
2) Create directory `%GOPATH%/src/github.com/kontaktio` ([What is `GOPATH`?](https://golang.org/cmd/go/#hdr-GOPATH_environment_variable))
3) Clone repo in kdmlight repository

To build simply run `go build` inside the repo's directory and run `kdmlight` executable. The build process might end with errors due to missing packages. If that's the case, check logs and run `go get` with missing packet's name, e.g. `go get github.com/gookit/color`.

Please keep in mind that `kdmlight` depends on [nRF Command Line Tools](https://www.nordicsemi.com/Software-and-tools/Development-Tools/nRF-Command-Line-Tools/Download) (`nrfjprog`). It is required for programming beacons through SEGGER J-Link programmers. Make sure all appropriate software and drivers for J-Link on your plaform are installed and working prior to using `kdmlight`.

## Usage
`go build` will prepare an executable for your platform. Before running it please put a package with order configuration inside the `Orders` directory. Then run the `kdmlight` executable and follow on-screen instructions.